
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { DetectedObject } from "../types";

export async function detectObjects(base64Image: string, mimeType: string): Promise<DetectedObject[]> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `Detect all major objects in this image. For each object, provide a label and its bounding box [ymin, xmin, ymax, xmax] in normalized coordinates from 0 to 1000.`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            objects: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  label: { type: Type.STRING },
                  box_2d: {
                    type: Type.ARRAY,
                    items: { type: Type.NUMBER },
                    description: "[ymin, xmin, ymax, xmax]",
                  },
                },
                required: ["label", "box_2d"],
              },
            },
          },
          required: ["objects"],
        },
      },
    });

    const jsonStr = response.text?.trim() || '{"objects": []}';
    const parsed = JSON.parse(jsonStr);
    return parsed.objects || [];
  } catch (error) {
    console.error("Error in detectObjects:", error);
    throw error;
  }
}
