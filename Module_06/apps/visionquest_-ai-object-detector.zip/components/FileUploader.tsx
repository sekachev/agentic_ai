
import React, { useRef } from 'react';

interface FileUploaderProps {
  onFileSelect: (file: File) => void;
  isLoading: boolean;
}

const FileUploader: React.FC<FileUploaderProps> = ({ onFileSelect, isLoading }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0]);
    }
  };

  const triggerUpload = () => {
    if (!isLoading) {
      fileInputRef.current?.click();
    }
  };

  return (
    <div 
      onClick={triggerUpload}
      className={`group relative border-2 border-dashed rounded-2xl p-8 transition-all cursor-pointer flex flex-col items-center justify-center gap-4 ${
        isLoading 
          ? 'border-zinc-800 bg-zinc-900/50 opacity-50 cursor-not-allowed' 
          : 'border-zinc-700 bg-zinc-900/30 hover:bg-zinc-800/50 hover:border-blue-500/50'
      }`}
    >
      <input 
        type="file" 
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />
      <div className="w-16 h-16 rounded-full bg-zinc-800 flex items-center justify-center group-hover:scale-110 transition-transform">
        <i className={`fa-solid ${isLoading ? 'fa-spinner fa-spin text-blue-500' : 'fa-cloud-arrow-up text-zinc-400 group-hover:text-blue-500'}`}></i>
      </div>
      <div className="text-center">
        <p className="text-lg font-medium text-zinc-200">
          {isLoading ? 'Processing image...' : 'Drop your image here or click to browse'}
        </p>
        <p className="text-sm text-zinc-500 mt-1">Supports JPG, PNG and WebP</p>
      </div>
    </div>
  );
};

export default FileUploader;
