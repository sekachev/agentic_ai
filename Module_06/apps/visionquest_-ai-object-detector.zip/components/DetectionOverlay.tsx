
import React from 'react';
import { DetectedObject } from '../types';

interface DetectionOverlayProps {
  objects: DetectedObject[];
  hoveredIndex: number | null;
  setHoveredIndex: (index: number | null) => void;
}

const COLORS = [
  'rgba(59, 130, 246, 0.8)', // Blue
  'rgba(16, 185, 129, 0.8)', // Emerald
  'rgba(245, 158, 11, 0.8)', // Amber
  'rgba(239, 68, 68, 0.8)',   // Red
  'rgba(139, 92, 246, 0.8)', // Violet
  'rgba(236, 72, 153, 0.8)', // Pink
];

const DetectionOverlay: React.FC<DetectionOverlayProps> = ({ objects, hoveredIndex, setHoveredIndex }) => {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-xl">
      {objects.map((obj, idx) => {
        const [ymin, xmin, ymax, xmax] = obj.box_2d;
        
        // Gemini returns normalized [0, 1000]
        const top = (ymin / 1000) * 100;
        const left = (xmin / 1000) * 100;
        const height = ((ymax - ymin) / 1000) * 100;
        const width = ((xmax - xmin) / 1000) * 100;
        
        const isHovered = hoveredIndex === idx;
        const color = COLORS[idx % COLORS.length];

        return (
          <div
            key={`${obj.label}-${idx}`}
            className="absolute border-2 transition-all pointer-events-auto"
            style={{
              top: `${top}%`,
              left: `${left}%`,
              height: `${height}%`,
              width: `${width}%`,
              borderColor: color,
              backgroundColor: isHovered ? color.replace('0.8', '0.1') : 'transparent',
              zIndex: isHovered ? 20 : 10,
              boxShadow: isHovered ? `0 0 20px ${color}` : 'none',
            }}
            onMouseEnter={() => setHoveredIndex(idx)}
            onMouseLeave={() => setHoveredIndex(null)}
          >
            <div 
              className="absolute top-0 left-0 -translate-y-full px-2 py-0.5 text-xs font-bold text-white rounded-t-sm whitespace-nowrap"
              style={{ backgroundColor: color }}
            >
              {obj.label}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default DetectionOverlay;
