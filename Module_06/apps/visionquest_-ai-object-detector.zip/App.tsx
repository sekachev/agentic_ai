
import React, { useState, useCallback } from 'react';
import { detectObjects } from './services/geminiService';
import { DetectedObject } from './types';
import FileUploader from './components/FileUploader';
import DetectionOverlay from './components/DetectionOverlay';

const App: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('');
  const [detections, setDetections] = useState<DetectedObject[]>([]);
  const [loading, setLoading] = useState(false);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = useCallback(async (file: File) => {
    setLoading(true);
    setError(null);
    setDetections([]);
    
    // Read file as base64
    const reader = new FileReader();
    reader.onload = async (e) => {
      const result = e.target?.result as string;
      if (!result) return;

      const base64Data = result.split(',')[1];
      const type = file.type;
      
      setImage(result);
      setMimeType(type);

      try {
        const results = await detectObjects(base64Data, type);
        setDetections(results);
      } catch (err) {
        console.error(err);
        setError("Failed to analyze image. Please check your API key and try again.");
      } finally {
        setLoading(false);
      }
    };
    reader.readAsDataURL(file);
  }, []);

  const reset = () => {
    setImage(null);
    setDetections([]);
    setError(null);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 selection:bg-blue-500/30">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-neutral-950/80 backdrop-blur-md border-b border-neutral-900 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
              <i className="fa-solid fa-eye text-white text-xl"></i>
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">VisionQuest</h1>
              <p className="text-xs text-neutral-500 font-medium">GEMINI 3 OBJECT DETECTION</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-6 text-sm text-neutral-400">
            <span className="hover:text-blue-400 transition-colors cursor-pointer">Documentation</span>
            <span className="hover:text-blue-400 transition-colors cursor-pointer">Settings</span>
            <button 
              onClick={reset}
              className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 rounded-lg text-neutral-200 transition-all font-medium"
            >
              New Analysis
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-24 pb-12 px-6 max-w-7xl mx-auto">
        {!image ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] gap-8">
            <div className="max-w-xl text-center">
              <h2 className="text-4xl sm:text-5xl font-extrabold mb-4 bg-gradient-to-br from-white to-neutral-500 bg-clip-text text-transparent">
                Visualize Intelligence
              </h2>
              <p className="text-lg text-neutral-400 mb-8">
                Upload any photo and our AI will automatically identify, label, and locate every major object within milliseconds.
              </p>
            </div>
            <div className="w-full max-w-2xl">
              <FileUploader onFileSelect={handleFileSelect} isLoading={loading} />
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Image Display */}
            <div className="lg:col-span-8 flex flex-col gap-4">
              <div className="relative bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl">
                <img 
                  src={image} 
                  alt="Source" 
                  className="w-full h-auto block"
                />
                <DetectionOverlay 
                  objects={detections} 
                  hoveredIndex={hoveredIndex} 
                  setHoveredIndex={setHoveredIndex}
                />
                
                {loading && (
                  <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] flex items-center justify-center">
                    <div className="bg-neutral-900 border border-neutral-800 p-6 rounded-2xl flex flex-col items-center gap-4 shadow-xl">
                      <div className="w-12 h-12 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin"></div>
                      <p className="text-sm font-medium animate-pulse text-neutral-300 tracking-wide uppercase">Neural Scan in Progress...</p>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="flex items-center justify-between text-neutral-400 px-2">
                <div className="flex items-center gap-4 text-sm">
                  <span><i className="fa-solid fa-image mr-2 opacity-50"></i> {detections.length} Objects Found</span>
                  <span className="opacity-20">|</span>
                  <span><i className="fa-solid fa-bolt mr-2 opacity-50"></i> Processed via Gemini 3</span>
                </div>
                <button 
                  onClick={() => setImage(null)}
                  className="text-sm hover:text-white transition-colors"
                >
                  <i className="fa-solid fa-trash-can mr-2"></i> Clear
                </button>
              </div>
            </div>

            {/* Side Panel: Object List */}
            <div className="lg:col-span-4 flex flex-col gap-6">
              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden flex flex-col h-[600px]">
                <div className="p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/50">
                  <h3 className="font-semibold text-neutral-200">Detections List</h3>
                  <span className="bg-blue-600/20 text-blue-400 text-xs px-2 py-1 rounded-full font-bold">
                    {detections.length} Total
                  </span>
                </div>
                
                <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-2">
                  {error && (
                    <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl text-red-400 text-sm">
                      <i className="fa-solid fa-circle-exclamation mr-2"></i> {error}
                    </div>
                  )}

                  {detections.length === 0 && !loading && !error && (
                    <div className="h-full flex flex-col items-center justify-center text-neutral-500 text-center px-6">
                      <i className="fa-solid fa-magnifying-glass text-3xl mb-4 opacity-20"></i>
                      <p className="text-sm">No objects detected or analysis pending.</p>
                    </div>
                  )}

                  {detections.map((obj, idx) => (
                    <div
                      key={idx}
                      onMouseEnter={() => setHoveredIndex(idx)}
                      onMouseLeave={() => setHoveredIndex(null)}
                      className={`group p-4 rounded-xl border transition-all cursor-default flex items-center justify-between ${
                        hoveredIndex === idx 
                          ? 'bg-neutral-800 border-blue-500/50 translate-x-1' 
                          : 'bg-neutral-800/30 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${
                          hoveredIndex === idx ? 'bg-blue-600 text-white' : 'bg-neutral-800 text-neutral-400'
                        }`}>
                          #{idx + 1}
                        </div>
                        <div>
                          <p className={`font-medium capitalize ${hoveredIndex === idx ? 'text-white' : 'text-neutral-300'}`}>
                            {obj.label}
                          </p>
                          <p className="text-[10px] text-neutral-500 uppercase font-bold tracking-widest mt-0.5">
                            Coords: {obj.box_2d.join(', ')}
                          </p>
                        </div>
                      </div>
                      <i className={`fa-solid fa-crosshairs transition-colors ${hoveredIndex === idx ? 'text-blue-500' : 'text-neutral-700'}`}></i>
                    </div>
                  ))}
                </div>

                <div className="p-4 bg-neutral-900/80 border-t border-neutral-800">
                  <button 
                    className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-semibold transition-all flex items-center justify-center gap-2 active:scale-95 shadow-lg shadow-blue-600/20"
                    onClick={() => {
                      const link = document.createElement('a');
                      link.href = image || '';
                      link.download = 'vision-quest-analysis.png';
                      link.click();
                    }}
                  >
                    <i className="fa-solid fa-download"></i> Export Result
                  </button>
                </div>
              </div>

              {/* Tips Section */}
              <div className="bg-blue-600/5 border border-blue-500/10 p-5 rounded-2xl">
                <h4 className="text-sm font-semibold text-blue-400 mb-2 flex items-center gap-2">
                  <i className="fa-solid fa-lightbulb"></i> Pro Tip
                </h4>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Hover over the detections in the list to highlight them specifically on the image map above. You can also hover over boxes directly.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto py-8 border-t border-neutral-900">
        <div className="max-w-7xl mx-auto px-6 text-center text-neutral-600 text-sm">
          Built with <i className="fa-solid fa-heart text-red-900 mx-1"></i> using Gemini 3 and React
        </div>
      </footer>
    </div>
  );
};

export default App;
