
import React from 'react';
import { UserIcon, PlusIcon, TrashIcon } from './Icons';

interface SidebarProps {
  students: string[];
  selectedStudent: string | null;
  onSelect: (name: string) => void;
  onAdd: () => void;
  onDelete: (name: string) => void;
  isLoading: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  students, 
  selectedStudent, 
  onSelect, 
  onAdd, 
  onDelete,
  isLoading 
}) => {
  return (
    <aside className="w-72 bg-white border-r border-slate-200 h-full flex flex-col overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
        <h2 className="font-bold text-slate-800 text-lg tracking-tight">Students</h2>
        <button 
          onClick={onAdd}
          className="p-1.5 rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow-sm"
          title="Add Student"
        >
          <PlusIcon className="w-4 h-4" />
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-1">
        {isLoading ? (
          <div className="flex items-center justify-center py-10 text-slate-400 text-sm">
            <span className="animate-pulse">Loading records...</span>
          </div>
        ) : students.length === 0 ? (
          <div className="text-center py-10">
            <p className="text-slate-400 text-sm">No students found.</p>
          </div>
        ) : (
          students.map((name) => (
            <div 
              key={name}
              className={`group flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all duration-200 ${
                selectedStudent === name 
                  ? 'bg-blue-50 text-blue-700 shadow-sm' 
                  : 'hover:bg-slate-50 text-slate-600'
              }`}
              onClick={() => onSelect(name)}
            >
              <div className="flex items-center space-x-3 truncate">
                <UserIcon className={`w-5 h-5 flex-shrink-0 ${selectedStudent === name ? 'text-blue-500' : 'text-slate-400'}`} />
                <span className="font-medium truncate text-sm">{name}</span>
              </div>
              <button 
                onClick={(e) => { e.stopPropagation(); onDelete(name); }}
                className="opacity-0 group-hover:opacity-100 p-1.5 hover:bg-red-50 hover:text-red-600 rounded-lg transition-all"
                title="Delete Record"
              >
                <TrashIcon className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>
      
      <div className="p-4 border-t border-slate-100 bg-slate-50/30">
        <div className="flex items-center space-x-2 text-xs text-slate-400 px-2">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
          <span>Connected to Olga API</span>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
