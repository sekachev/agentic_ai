
import React from 'react';
// We use a simpler approach since we can't bundle large libs easily
// but we'll try to use standard markdown conventions with basic CSS
import { AIInsight } from '../types';

interface PreviewProps {
  content: string;
  insight: AIInsight | null;
}

const Preview: React.FC<PreviewProps> = ({ content, insight }) => {
  return (
    <div className="flex flex-col h-full bg-slate-50 overflow-hidden">
      <div className="p-4 border-b border-slate-200 bg-white sticky top-0 z-10 flex items-center h-[73px]">
        <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Live Preview & Analysis</h2>
      </div>
      <div className="flex-1 overflow-y-auto p-8 max-w-4xl mx-auto w-full">
        {insight && (
          <div className="mb-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
            </div>
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg flex items-center space-x-2">
                  <span className="p-1 bg-white/20 rounded-lg"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg></span>
                  <span>Gemini Intel Report</span>
                </h3>
                {insight.suggestedGrade && (
                  <span className="bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                    Grade: {insight.suggestedGrade}
                  </span>
                )}
              </div>
              <p className="text-white/90 text-sm mb-6 leading-relaxed bg-white/10 p-4 rounded-xl border border-white/20">{insight.summary}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white/10 p-4 rounded-xl border border-white/20">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-white/70 mb-2">Key Strengths</h4>
                  <ul className="space-y-1">
                    {insight.strengths.map((s, i) => (
                      <li key={i} className="text-xs flex items-start space-x-2">
                        <span className="text-green-300">✓</span>
                        <span className="text-white/90">{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-white/10 p-4 rounded-xl border border-white/20">
                  <h4 className="text-xs font-bold uppercase tracking-widest text-white/70 mb-2">Opportunities</h4>
                  <ul className="space-y-1">
                    {insight.improvements.map((imp, i) => (
                      <li key={i} className="text-xs flex items-start space-x-2">
                        <span className="text-blue-200">→</span>
                        <span className="text-white/90">{imp}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {content.trim() === '' ? (
          <div className="flex flex-col items-center justify-center h-64 text-slate-400 border-2 border-dashed border-slate-200 rounded-2xl bg-white">
            <svg className="w-12 h-12 mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            <p className="font-medium">No content to preview</p>
            <p className="text-xs mt-1">Start writing in the editor to see it here</p>
          </div>
        ) : (
          <div className="markdown-content bg-white p-12 rounded-2xl shadow-sm border border-slate-200 text-slate-800">
            {/* Simple Markdown Rendering logic using lines */}
            {content.split('\n').map((line, i) => {
              if (line.startsWith('# ')) return <h1 key={i}>{line.replace('# ', '')}</h1>;
              if (line.startsWith('## ')) return <h2 key={i}>{line.replace('## ', '')}</h2>;
              if (line.startsWith('### ')) return <h3 key={i}>{line.replace('### ', '')}</h3>;
              if (line.startsWith('- ') || line.startsWith('* ')) return <ul key={i}><li>{line.substring(2)}</li></ul>;
              if (line.startsWith('> ')) return <blockquote key={i}>{line.replace('> ', '')}</blockquote>;
              if (line.trim() === '') return <br key={i} />;
              return <p key={i}>{line}</p>;
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default Preview;
