
import React from 'react';
import { SaveIcon, SparklesIcon } from './Icons';

interface EditorProps {
  value: string;
  onChange: (val: string) => void;
  onSave: () => void;
  onAnalyze: () => void;
  isSaving: boolean;
  isAnalyzing: boolean;
  studentName: string;
}

const Editor: React.FC<EditorProps> = ({ 
  value, 
  onChange, 
  onSave, 
  onAnalyze, 
  isSaving, 
  isAnalyzing,
  studentName 
}) => {
  return (
    <div className="flex flex-col h-full bg-white">
      <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-white sticky top-0 z-10">
        <div className="flex flex-col">
          <h1 className="text-xl font-bold text-slate-800 tracking-tight">{studentName}</h1>
          <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold mt-0.5">Edit Mode</p>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            onClick={onAnalyze}
            disabled={isAnalyzing || !value.trim()}
            className="flex items-center space-x-2 px-4 py-2 bg-indigo-50 text-indigo-700 rounded-lg hover:bg-indigo-100 transition-all disabled:opacity-50 font-semibold text-sm shadow-sm"
          >
            {isAnalyzing ? (
              <span className="animate-pulse">Thinking...</span>
            ) : (
              <>
                <SparklesIcon className="w-4 h-4" />
                <span>AI Insights</span>
              </>
            )}
          </button>
          <button 
            onClick={onSave}
            disabled={isSaving}
            className="flex items-center space-x-2 px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-900 transition-all disabled:opacity-50 font-semibold text-sm shadow-md"
          >
            <SaveIcon className="w-4 h-4" />
            <span>{isSaving ? 'Saving...' : 'Save File'}</span>
          </button>
        </div>
      </div>
      <textarea
        className="flex-1 p-8 text-slate-700 bg-white font-mono text-sm leading-relaxed outline-none resize-none selection:bg-blue-100"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="# Student Assessment Record&#10;&#10;Name: John Doe&#10;Date: 2024-05-20&#10;&#10;## Performance Overview&#10;Excellent progress this semester..."
      />
    </div>
  );
};

export default Editor;
