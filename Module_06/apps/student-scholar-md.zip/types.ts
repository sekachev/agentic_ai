
export interface StudentData {
  content: string;
}

export interface ValidationError {
  loc: (string | number)[];
  msg: string;
  type: string;
}

export interface HTTPValidationError {
  detail: ValidationError[];
}

export interface AIInsight {
  summary: string;
  strengths: string[];
  improvements: string[];
  suggestedGrade?: string;
}
