
import { StudentData } from '../types';

const BASE_URL = 'https://api.olga.qix.ee';

export const listStudents = async (): Promise<string[]> => {
  const response = await fetch(`${BASE_URL}/students`);
  if (!response.ok) throw new Error('Failed to fetch students list');
  return response.json();
};

export const getStudentContent = async (name: string): Promise<string> => {
  const response = await fetch(`${BASE_URL}/students/${name}`);
  if (!response.ok) throw new Error('Failed to fetch student content');
  const data = await response.json();
  return data.content || '';
};

export const saveStudentContent = async (name: string, content: string): Promise<void> => {
  const response = await fetch(`${BASE_URL}/students/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content }),
  });
  if (!response.ok) throw new Error('Failed to save student content');
};

export const deleteStudent = async (name: string): Promise<void> => {
  const response = await fetch(`${BASE_URL}/students/${name}`, {
    method: 'DELETE',
  });
  if (!response.ok) throw new Error('Failed to delete student');
};
