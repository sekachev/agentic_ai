
import React, { useState, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import Editor from './components/Editor';
import Preview from './components/Preview';
import Modal from './components/Modal';
import { listStudents, getStudentContent, saveStudentContent, deleteStudent } from './services/api';
import { analyzeStudentContent } from './services/gemini';
import { AIInsight } from './types';
import { LoaderIcon, PlusIcon } from './components/Icons';

const App: React.FC = () => {
  const [students, setStudents] = useState<string[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);
  const [content, setContent] = useState<string>('');
  const [insight, setInsight] = useState<AIInsight | null>(null);
  const [isLoadingList, setIsLoadingList] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newStudentName, setNewStudentName] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  const fetchList = useCallback(async () => {
    setIsLoadingList(true);
    try {
      const data = await listStudents();
      setStudents(data);
    } catch (err) {
      setError('Failed to load student list.');
    } finally {
      setIsLoadingList(false);
    }
  }, []);

  useEffect(() => {
    fetchList();
  }, [fetchList]);

  const handleSelectStudent = async (name: string) => {
    setSelectedStudent(name);
    setInsight(null);
    try {
      const data = await getStudentContent(name);
      setContent(data);
    } catch (err) {
      setError(`Failed to fetch content for ${name}.`);
    }
  };

  const handleSave = async () => {
    if (!selectedStudent) return;
    setIsSaving(true);
    try {
      await saveStudentContent(selectedStudent, content);
    } catch (err) {
      setError('Failed to save content.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (name: string) => {
    if (!confirm(`Are you sure you want to delete ${name}'s record?`)) return;
    try {
      await deleteStudent(name);
      if (selectedStudent === name) {
        setSelectedStudent(null);
        setContent('');
        setInsight(null);
      }
      fetchList();
    } catch (err) {
      setError(`Failed to delete student ${name}.`);
    }
  };

  const handleCreateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentName.trim()) return;
    
    setIsCreating(true);
    try {
      const name = newStudentName.trim();
      // Initialize with a template
      const initialContent = `# ${name}\n\nDate: ${new Date().toLocaleDateString()}\n\n## Assessment Results\n- Progress: \n- Areas for improvement: \n`;
      
      await saveStudentContent(name, initialContent);
      await fetchList();
      
      setSelectedStudent(name);
      setContent(initialContent);
      setInsight(null);
      setIsAddModalOpen(false);
      setNewStudentName('');
    } catch (err) {
      setError('Failed to create new student record.');
    } finally {
      setIsCreating(false);
    }
  };

  const handleAnalyze = async () => {
    if (!content.trim()) return;
    setIsAnalyzing(true);
    try {
      const res = await analyzeStudentContent(content);
      setInsight(res);
    } catch (err) {
      setError('AI Analysis failed. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-slate-100 text-slate-900 overflow-hidden">
      {/* Sidebar - Fixed Width */}
      <Sidebar 
        students={students}
        selectedStudent={selectedStudent}
        onSelect={handleSelectStudent}
        onAdd={() => setIsAddModalOpen(true)}
        onDelete={handleDelete}
        isLoading={isLoadingList}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col md:flex-row h-full overflow-hidden bg-white">
        {selectedStudent ? (
          <>
            {/* Editor Pane */}
            <div className="w-full md:w-1/2 h-1/2 md:h-full border-r border-slate-200">
              <Editor 
                studentName={selectedStudent}
                value={content}
                onChange={setContent}
                onSave={handleSave}
                onAnalyze={handleAnalyze}
                isSaving={isSaving}
                isAnalyzing={isAnalyzing}
              />
            </div>

            {/* Preview Pane */}
            <div className="w-full md:w-1/2 h-1/2 md:h-full bg-slate-50">
              <Preview content={content} insight={insight} />
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-12 text-center bg-slate-50">
            <div className="max-w-md bg-white p-12 rounded-3xl shadow-xl border border-slate-100">
              <div className="w-20 h-20 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
              </div>
              <h1 className="text-3xl font-extrabold text-slate-800 mb-4 tracking-tight">Student Scholar MD</h1>
              <p className="text-slate-500 mb-8 leading-relaxed">Select a student record from the sidebar to view assessment data, or create a new profile to begin tracking performance.</p>
              <button 
                onClick={() => setIsAddModalOpen(true)}
                className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all font-bold shadow-lg shadow-blue-200"
              >
                Create New Profile
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Add Student Modal */}
      <Modal 
        isOpen={isAddModalOpen} 
        onClose={() => {
          setIsAddModalOpen(false);
          setNewStudentName('');
        }} 
        title="New Student Record"
      >
        <form onSubmit={handleCreateStudent} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Student Name</label>
            <input 
              autoFocus
              type="text"
              value={newStudentName}
              onChange={(e) => setNewStudentName(e.target.value)}
              placeholder="e.g. Alice Thompson"
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-slate-800"
              required
            />
          </div>
          <div className="pt-2 flex flex-col space-y-3">
            <button 
              type="submit"
              disabled={isCreating || !newStudentName.trim()}
              className="w-full py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all font-bold shadow-md shadow-blue-100 disabled:opacity-50 flex items-center justify-center"
            >
              {isCreating ? <LoaderIcon className="w-5 h-5 mr-2" /> : <PlusIcon className="w-5 h-5 mr-2" />}
              {isCreating ? 'Creating...' : 'Create Record'}
            </button>
            <p className="text-[10px] text-slate-400 text-center uppercase tracking-tight">This will create a new .md assessment file</p>
          </div>
        </form>
      </Modal>

      {/* Global Error Toast */}
      {error && (
        <div className="fixed bottom-6 right-6 bg-red-600 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center space-x-4 animate-bounce z-50">
          <span className="font-medium">{error}</span>
          <button onClick={() => setError(null)} className="text-white/70 hover:text-white font-bold px-2">✕</button>
        </div>
      )}
    </div>
  );
};

export default App;
