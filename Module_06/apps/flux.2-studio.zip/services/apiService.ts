
import { 
  GenerationParams, 
  GenerationTriggerResponse, 
  PollingResponse, 
  HistoryItem,
  ModelType
} from '../types';

// Using HTTPS to avoid Mixed Content blocks in modern browsers
const BASE_URL = 'https://api.qix.ee';
const API_KEY = 'c7edb8649e40dff39a7b14a396de106d';

const handleFetchError = (error: any) => {
  if (error.name === 'TypeError' && error.message === 'Failed to fetch') {
    throw new Error('Connection failed. This is likely a CORS issue or the API server is unreachable. Please check if your browser blocks requests to api.qix.ee.');
  }
  throw error;
};

export const apiService = {
  async triggerGeneration(model: ModelType, params: GenerationParams): Promise<GenerationTriggerResponse> {
    try {
      const response = await fetch(`${BASE_URL}/v1/${model}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-key': API_KEY,
        },
        body: JSON.stringify(params),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.message || `API Error: ${response.status} ${response.statusText}`);
      }

      return response.json();
    } catch (err) {
      return handleFetchError(err);
    }
  },

  async pollResult(taskId: string): Promise<PollingResponse> {
    try {
      const response = await fetch(`${BASE_URL}/v1/get_result?id=${taskId}`, {
        headers: {
          'x-key': API_KEY,
        },
      });

      if (!response.ok) {
        throw new Error(`Polling failed: ${response.statusText}`);
      }

      return response.json();
    } catch (err) {
      return handleFetchError(err);
    }
  },

  async getHistory(limit: number = 50, offset: number = 0, query?: string): Promise<HistoryItem[]> {
    try {
      const url = new URL(`${BASE_URL}/history`);
      url.searchParams.append('limit', limit.toString());
      url.searchParams.append('offset', offset.toString());
      if (query) {
        url.searchParams.append('query', query);
      }

      const response = await fetch(url.toString(), {
        headers: {
          'x-key': API_KEY,
        },
      });

      if (!response.ok) {
        throw new Error(`History fetch failed: ${response.statusText}`);
      }

      return response.json();
    } catch (err) {
      return handleFetchError(err);
    }
  }
};
