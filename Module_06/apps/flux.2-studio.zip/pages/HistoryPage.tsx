
import React, { useState, useEffect } from 'react';
import { apiService } from '../services/apiService';
import { HistoryItem } from '../types';
import { ImageCard } from '../components/ImageCard';

export const HistoryPage: React.FC = () => {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [offset, setOffset] = useState(0);
  const LIMIT = 24;

  const fetchHistory = async (newOffset: number = 0, searchQuery?: string) => {
    setLoading(true);
    try {
      const data = await apiService.getHistory(LIMIT, newOffset, searchQuery);
      if (newOffset === 0) {
        setHistory(data);
      } else {
        setHistory(prev => [...prev, ...data]);
      }
      setOffset(newOffset);
      setError(null);
    } catch (err: any) {
      setError(err.message || "Failed to load history.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchHistory(0, query);
  };

  const loadMore = () => {
    fetchHistory(offset + LIMIT, query);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white mb-1">Your Gallery</h2>
          <p className="text-zinc-500">History of all successful generations</p>
        </div>
        
        <form onSubmit={handleSearch} className="w-full md:w-auto flex gap-2">
          <input 
            type="text" 
            placeholder="Search prompt..." 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 md:w-64 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          />
          <button 
            type="submit"
            className="px-4 py-2 bg-zinc-800 text-white rounded-xl hover:bg-zinc-700 transition-colors font-semibold text-sm"
          >
            Search
          </button>
        </form>
      </div>

      {error && (
        <div className="p-6 bg-red-500/10 border border-red-500/20 rounded-2xl text-center">
          <p className="text-red-400 font-medium">{error}</p>
          <button onClick={() => fetchHistory(0, query)} className="mt-4 text-sm text-red-500 hover:underline">Try Again</button>
        </div>
      )}

      {!loading && history.length === 0 && !error && (
        <div className="py-20 flex flex-col items-center justify-center glass-panel rounded-3xl border-dashed">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-zinc-700 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <h3 className="text-xl font-bold text-zinc-400">No images found</h3>
          <p className="text-zinc-600 mt-1">Start generating to see your history here.</p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
        {history.map((item) => {
          let metadata = { aspect_ratio: '1:1' };
          try {
            metadata = JSON.parse(item.metadata);
          } catch(e) {}
          
          return (
            <ImageCard 
              key={item.id}
              url={item.url}
              prompt={item.prompt}
              model={item.model}
              createdAt={item.created_at}
              aspectRatio={metadata.aspect_ratio}
            />
          );
        })}
      </div>

      {(loading || history.length > 0) && (
        <div className="py-12 flex flex-col items-center justify-center">
          {loading ? (
            <div className="flex items-center gap-3 text-zinc-500">
              <div className="w-5 h-5 border-2 border-zinc-700 border-t-blue-500 rounded-full animate-spin"></div>
              <span className="font-medium">Loading magic...</span>
            </div>
          ) : (
            <button 
              onClick={loadMore}
              className="px-8 py-3 bg-zinc-900 border border-zinc-800 text-zinc-400 rounded-xl hover:bg-zinc-800 hover:text-white transition-all font-semibold"
            >
              Load More Generations
            </button>
          )}
        </div>
      )}
    </div>
  );
};
