
import React, { useState, useEffect, useRef } from 'react';
import { apiService } from '../services/apiService';
import { ModelType, AspectRatio, GenerationTask, PollingResponse } from '../types';
import { ImageCard } from '../components/ImageCard';

export const GeneratorPage: React.FC = () => {
  const [model, setModel] = useState<ModelType>('flux-2-klein-4b');
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [steps, setSteps] = useState(4);
  const [seed, setSeed] = useState<number | undefined>(undefined);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentTask, setCurrentTask] = useState<GenerationTask | null>(null);
  const [error, setError] = useState<string | null>(null);

  const pollingTimerRef = useRef<number | null>(null);

  const clearPolling = () => {
    if (pollingTimerRef.current) {
      window.clearInterval(pollingTimerRef.current);
      pollingTimerRef.current = null;
    }
  };

  const startPolling = (taskId: string) => {
    clearPolling();
    
    pollingTimerRef.current = window.setInterval(async () => {
      try {
        const statusResponse: PollingResponse = await apiService.pollResult(taskId);
        
        setCurrentTask(prev => {
          if (!prev) return null;
          return {
            ...prev,
            status: statusResponse.status,
            resultUrl: statusResponse.result?.sample
          };
        });

        if (statusResponse.status === 'Ready') {
          clearPolling();
          setIsGenerating(false);
        } else if (statusResponse.status === 'Error') {
          clearPolling();
          setIsGenerating(false);
          setError('Model encountered an error during generation.');
        }
      } catch (err) {
        console.error("Polling error:", err);
      }
    }, 2000);
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isGenerating) return;

    setError(null);
    setIsGenerating(true);
    setCurrentTask(null);

    try {
      const trigger = await apiService.triggerGeneration(model, {
        prompt,
        aspect_ratio: aspectRatio,
        steps,
        seed: seed || Math.floor(Math.random() * 1000000)
      });

      setCurrentTask({
        id: trigger.id,
        prompt,
        status: 'Task_Queued',
        model
      });

      startPolling(trigger.id);
    } catch (err: any) {
      setError(err.message || "Failed to start generation.");
      setIsGenerating(false);
    }
  };

  useEffect(() => {
    return () => clearPolling();
  }, []);

  return (
    <div className="grid lg:grid-cols-12 gap-8 items-start">
      {/* Left Sidebar - Controls */}
      <div className="lg:col-span-4 space-y-6 lg:sticky lg:top-24">
        <form onSubmit={handleGenerate} className="glass-panel rounded-2xl p-6 shadow-xl border-zinc-800 space-y-6">
          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-zinc-500 mb-2">Model</label>
            <div className="grid grid-cols-2 gap-2 bg-zinc-900/50 p-1 rounded-xl border border-zinc-800">
              {(['flux-2-klein-4b', 'flux-2-klein-9b'] as ModelType[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setModel(m)}
                  className={`py-2 rounded-lg text-sm font-semibold transition-all ${model === m ? 'bg-zinc-800 text-white shadow-sm ring-1 ring-zinc-700' : 'text-zinc-500 hover:text-zinc-300'}`}
                >
                  {m === 'flux-2-klein-4b' ? '4B Klein' : '9B Pro'}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-zinc-500 mb-2">Prompt</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="A cosmic forest with bioluminescent mushrooms..."
              className="w-full h-32 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all resize-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-zinc-500 mb-2">Aspect Ratio</label>
              <select
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                <option value="1:1">1:1 Square</option>
                <option value="3:4">3:4 Portrait</option>
                <option value="4:3">4:3 Photo</option>
                <option value="9:16">9:16 Cinematic</option>
                <option value="16:9">16:9 Widescreen</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-zinc-500 mb-2">Steps ({steps})</label>
              <input
                type="range"
                min="1"
                max="12"
                value={steps}
                onChange={(e) => setSteps(parseInt(e.target.value))}
                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-500 mt-3"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isGenerating || !prompt.trim()}
            className={`w-full py-4 rounded-xl font-bold text-white transition-all shadow-lg ${isGenerating ? 'bg-zinc-800 cursor-not-allowed text-zinc-500' : 'accent-gradient hover:opacity-90 active:scale-95 shadow-blue-500/20'}`}
          >
            {isGenerating ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                {currentTask?.status === 'Processing' ? 'Rendering...' : 'In Queue...'}
              </span>
            ) : (
              'Generate Masterpiece'
            )}
          </button>
        </form>

        {error && (
          <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl space-y-3">
             <div className="flex items-start gap-3">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-500 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <p className="text-sm text-red-400 font-medium leading-snug">{error}</p>
             </div>
             {error.includes('Connection failed') && (
               <div className="text-[11px] text-zinc-500 bg-black/20 p-2 rounded border border-zinc-800 leading-relaxed">
                  <strong>Troubleshooting:</strong><br/>
                  1. Check if the API is available via <a href="https://api.qix.ee/history" target="_blank" className="text-blue-400 underline">this link</a>.<br/>
                  2. Ensure your browser is not blocking "Mixed Content" or CORS requests.<br/>
                  3. Try disabling ad-blockers for this domain.
               </div>
             )}
          </div>
        )}
      </div>

      {/* Right Content - Result Display */}
      <div className="lg:col-span-8 flex flex-col gap-6 h-full min-h-[600px]">
        {currentTask ? (
          <div className="flex-1 flex flex-col items-center justify-center bg-zinc-950/50 rounded-3xl border border-zinc-800 border-dashed p-8 relative overflow-hidden">
            {currentTask.status === 'Ready' && currentTask.resultUrl ? (
              <div className="w-full h-full flex flex-col items-center gap-6">
                <div className="max-w-xl w-full">
                  <ImageCard 
                    url={currentTask.resultUrl} 
                    prompt={currentTask.prompt} 
                    model={currentTask.model}
                    aspectRatio={aspectRatio}
                  />
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-bold mb-1 text-white">Generation Complete</h3>
                  <p className="text-zinc-500 text-sm">Your image is ready</p>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center text-center space-y-6">
                <div className="relative">
                  <div className="w-32 h-32 rounded-full border-4 border-zinc-800 border-t-blue-500 animate-spin"></div>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white mb-2">
                    {currentTask.status === 'Task_Queued' ? 'Queued' : 'Magic in Progress'}
                  </h3>
                  <p className="text-zinc-400 max-w-sm mx-auto">
                    ID: <span className="font-mono text-zinc-500">{currentTask.id}</span>
                  </p>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center bg-zinc-950/50 rounded-3xl border border-zinc-800 border-dashed p-12 text-center">
             <div className="w-20 h-20 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mb-6 shadow-2xl">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-zinc-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
             </div>
             <h3 className="text-2xl font-bold text-white mb-3">Masterpieces await</h3>
             <p className="text-zinc-500 max-w-md mx-auto leading-relaxed text-sm">
               Enter a description to start generating high-quality AI images with Flux.2 Klein.
             </p>
          </div>
        )}
      </div>
    </div>
  );
};
