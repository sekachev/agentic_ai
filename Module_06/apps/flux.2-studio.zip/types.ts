
export type ModelType = 'flux-2-klein-4b' | 'flux-2-klein-9b';

export type AspectRatio = '1:1' | '3:4' | '4:3' | '9:16' | '16:9';

export interface GenerationParams {
  prompt: string;
  aspect_ratio: AspectRatio;
  steps: number;
  seed?: number;
}

export interface GenerationTriggerResponse {
  id: string;
  status: string;
  polling_url: string;
}

export interface PollingResponse {
  id: string;
  status: 'Task_Queued' | 'Processing' | 'Ready' | 'Error';
  result?: {
    sample: string;
  };
}

export interface HistoryItem {
  id: string;
  prompt: string;
  model: ModelType;
  status: string;
  result_url: string;
  url: string;
  metadata: string; // JSON string
  created_at: string;
}

export interface GenerationTask {
  id: string;
  prompt: string;
  status: PollingResponse['status'];
  resultUrl?: string;
  error?: string;
  model: ModelType;
}
