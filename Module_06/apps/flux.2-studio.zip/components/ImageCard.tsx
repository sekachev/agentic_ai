
import React, { useState } from 'react';

interface ImageCardProps {
  url: string;
  prompt: string;
  model?: string;
  createdAt?: string;
  aspectRatio?: string;
}

export const ImageCard: React.FC<ImageCardProps> = ({ url, prompt, model, createdAt, aspectRatio }) => {
  const [loaded, setLoaded] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);

  return (
    <div 
      className="group relative rounded-2xl overflow-hidden glass-panel border border-zinc-800 transition-all hover:border-zinc-600 hover:shadow-2xl hover:shadow-blue-500/10"
      onMouseEnter={() => setShowPrompt(true)}
      onMouseLeave={() => setShowPrompt(false)}
    >
      <div className={`aspect-square bg-zinc-900 relative flex items-center justify-center overflow-hidden`}>
        {!loaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-zinc-900 animate-pulse">
            <div className="w-8 h-8 border-2 border-zinc-700 border-t-blue-500 rounded-full animate-spin"></div>
          </div>
        )}
        <img 
          src={url} 
          alt={prompt}
          className={`w-full h-full object-cover transition-opacity duration-500 ${loaded ? 'opacity-100' : 'opacity-0'}`}
          onLoad={() => setLoaded(true)}
        />
        
        <div className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 flex flex-col justify-end p-4 ${showPrompt ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          <p className="text-sm text-zinc-200 line-clamp-3 mb-3 leading-relaxed">
            {prompt}
          </p>
          <div className="flex flex-wrap gap-2 mb-4">
            {model && <span className="text-[10px] uppercase font-bold tracking-wider bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded border border-blue-500/30">{model}</span>}
            {aspectRatio && <span className="text-[10px] uppercase font-bold tracking-wider bg-zinc-700 text-zinc-300 px-2 py-0.5 rounded border border-zinc-600">{aspectRatio}</span>}
          </div>
          <div className="flex gap-2">
            <a 
              href={url} 
              target="_blank" 
              rel="noreferrer"
              className="flex-1 text-center py-2 bg-zinc-100 text-black font-semibold text-xs rounded-lg hover:bg-white transition-colors"
            >
              Open Large
            </a>
            <button 
              onClick={() => {
                fetch(url).then(res => res.blob()).then(blob => {
                  const a = document.createElement('a');
                  a.href = URL.createObjectURL(blob);
                  a.download = `flux-gen-${Date.now()}.png`;
                  a.click();
                });
              }}
              className="px-3 py-2 bg-zinc-800 text-zinc-100 rounded-lg hover:bg-zinc-700 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      {createdAt && (
        <div className="p-3 border-t border-zinc-900 bg-zinc-950/40 flex justify-between items-center">
          <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-semibold">
            {new Date(createdAt).toLocaleDateString()}
          </span>
          <span className="text-[10px] text-zinc-600 font-mono">
            #{url.split('/').pop()?.split('.').shift()?.slice(-8)}
          </span>
        </div>
      )}
    </div>
  );
};
