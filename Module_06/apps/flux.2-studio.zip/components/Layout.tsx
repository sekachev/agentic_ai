
import React from 'react';
import { NavLink } from 'react-router-dom';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 glass-panel border-b border-zinc-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl accent-gradient flex items-center justify-center font-bold text-xl shadow-lg shadow-blue-500/20">
            F
          </div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Flux.2 <span className="text-blue-400">Studio</span>
          </h1>
        </div>
        
        <nav className="flex items-center gap-1 bg-zinc-900/50 p-1 rounded-lg border border-zinc-800">
          <NavLink 
            to="/" 
            className={({ isActive }) => `px-4 py-2 rounded-md text-sm font-medium transition-all ${isActive ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-200'}`}
          >
            Generate
          </NavLink>
          <NavLink 
            to="/history" 
            className={({ isActive }) => `px-4 py-2 rounded-md text-sm font-medium transition-all ${isActive ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-200'}`}
          >
            History
          </NavLink>
        </nav>

        <div className="hidden md:block">
          <span className="text-xs text-zinc-500 font-mono bg-zinc-900 px-2 py-1 rounded border border-zinc-800">
            v2.1 Stable
          </span>
        </div>
      </header>
      
      <main className="flex-1 container mx-auto px-4 py-8 max-w-7xl">
        {children}
      </main>

      <footer className="py-8 text-center text-zinc-600 text-xs border-t border-zinc-900">
        <p>&copy; 2024 Flux.2 Studio. Powered by Black Forest Labs compatible API.</p>
      </footer>
    </div>
  );
};
